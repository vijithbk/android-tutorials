package com.example.wftest1

import com.google.gson.annotations.SerializedName

data class Data(
    @SerializedName("MRData")
    val mrdata: Mrdata
)

data class Mrdata(
    val series: String,
    val total: String,
    @SerializedName("RaceTable")
    val raceTable: RaceTable
)

data class RaceTable(
    @SerializedName("Races")
    val races: List<Race>
)

data class Race(
    @SerializedName("Results")
    val results: List<Result>
)

data class Result(
    @SerializedName("Driver")
    val driver: DriverDetails
)

data class DriverDetails(
    val driverId: String,
    val givenName: String,
    val familyName: String
)
