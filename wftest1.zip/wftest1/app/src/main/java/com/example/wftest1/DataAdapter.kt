package com.example.wftest1

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Adapter
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class DataAdapter (val context: Context, val result:List<Result>) : RecyclerView.Adapter<DataAdapter.DriverViewHolder>() {

    class DriverViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var slno = itemView.findViewById<TextView>(R.id.slno)
        var name = itemView.findViewById<TextView>(R.id.name)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DriverViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_layout, parent, false)
        return DriverViewHolder(view)
    }

    override fun onBindViewHolder(holder: DriverViewHolder, position: Int) {
        val item = result[position]
        Log.d("Vijith", item.toString())
        holder.slno.text = (position.toInt()+1).toString()
        holder.name.text = "${item.driver.givenName} ${item.driver.familyName}"
    }

    override fun getItemCount(): Int {
        return result.size
    }
}