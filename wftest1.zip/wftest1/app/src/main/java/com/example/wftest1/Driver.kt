package com.example.wftest1

data class Driver (val givenName:String, val familyName:String)