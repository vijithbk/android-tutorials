package com.example.wftest1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    lateinit var adapter: DataAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        getDrivers()
    }

    private  fun getDrivers() {
        val data = DataService.dataInstance.getDrivers()
        data.enqueue(object: retrofit2.Callback<Data>{
            override fun onResponse(call: Call<Data>, response: Response<Data>) {
                val data = response.body()
                if(data != null) {
                    Log.d("Vijith", data.toString())
                    adapter = DataAdapter(this@MainActivity, data.mrdata.raceTable.races[0].results)
                    val dataList = findViewById<RecyclerView>(R.id.dataList)

                    dataList.adapter = adapter
                    dataList.layoutManager = LinearLayoutManager(this@MainActivity)
                }
            }

            override fun onFailure(call: Call<Data>, t: Throwable) {
                Log.d("Vijith", "Error occured while retrieving" + t.message)
            }
        })
    }
}