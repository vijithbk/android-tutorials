package com.example.wftest1

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET


// https://ergast.com/api/f1/2004/1/results.json

const val URL = "https://ergast.com/"
const val API = "api/f1/2004/1/results.json"

interface WFService {
    @GET(API)
    fun getDrivers() : Call<Data>
}

object DataService {
    val dataInstance: WFService
    init {
        val retrofit = Retrofit.Builder()
            .baseUrl(URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        dataInstance = retrofit.create(WFService::class.java)
    }
}